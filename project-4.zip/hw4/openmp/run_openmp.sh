#!/bin/bash
#SBATCH --job-name=scorecard_openmp
#SBATCH --output=logs/out_%j.txt
#SBATCH --error=logs/err_%j.txt
#SBATCH --time=00:30:00
#SBATCH --partition=batch.q
#SBATCH --constraint=moles

#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=128M

echo "=============================="
echo "Job ID: $SLURM_JOB_ID"
echo "Nodes: $SLURM_JOB_NUM_NODES"
echo "Threads: $SLURM_CPUS_PER_TASK"
echo "Mem per CPU: $SLURM_MEM_PER_CPU"
echo "=============================="

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK

# Run with timing
/usr/bin/time -v ./openmp_maximum $OMP_NUM_THREADS > /dev/null